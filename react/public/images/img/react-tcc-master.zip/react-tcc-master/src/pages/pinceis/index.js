import Cabecalho from "../../components/cabecalho"
import "./index.scss"

export default function Pinceis() {

    return(
        <div className="pinceis">

            <Cabecalho/>

            <h1>Pinceis</h1>

            
            <div> 
                
                <div>  
                   <img src="/assets/img/produtos/imag1.png"></img>
                   <p>Pincéis Atlas 319/5 Trincha para Pintura 2" Amarelo
                    </p>
                   <p2></p2>
                   <h1>R$ 7,70/cada</h1>
               </div>    
           
               <div>  
                   <img src="/assets/img/produtos/imag2.png"></img>
                   <p>Pincéis Atlas AT415/5 Trincha para Pintura 2"
                    </p>
                   <p2></p2>
                   <h1>R$ 16,90/cada
                    </h1>
               </div>    

               <div>  
                   <img src="/assets/img/produtos/imag3.png"></img>
                   <p>Pincéis Atlas 417/4 Trincha para Pintura LATEX&ACRIL 1 1/2
                    </p>
                   <p2>de: R$ 9,35</p2>
                   <h1>R$ 7,80/cada</h1>
               </div>    


           </div>

           <div> 
           
                <div>  
                   <img src="/assets/img/produtos/imag4.png"></img>
                   <p>Pincel Redondo Keramik Cores 311
                    </p>
                   <p2>de: R$ 22,90/cada</p2>
                   <h1>por: R$ 18,90/cada</h1>
               </div>    
           
               <div>  
                   <img src="/assets/img/produtos/imag5.png"></img>
                   <p>Pincel de ponta com faixa de ângulo de ponta de 6,3 cm</p>
                   <p2></p2>
                   <h1>R$ 58,25/cada</h1>
               </div>    

               <div>  
                   <img src="/assets/img/produtos/imag6.png"></img>
                   <p>Pincéis Atlas 319/5 Trincha para Pintura 2" Amarelo
                    </p>
                   <p2></p2>
                   <h1>R$ 26,70/cada</h1>
               </div>    


           </div>

           <div> 
           
                <div>  
                   <img src="/assets/img/produtos/imag7.png"></img>
                   <p>Silicone pincel flexível acrílico e água baseada pintura ferramenta</p>
                   <p2>de: R$50,10</p2>
                   <h1>R$ 49,74/cada</h1>
               </div>    
           
               <div>  
                   <img src="/assets/img/produtos/imag8.png"></img>
                   <p>Pincel Modelador de Silicone N° 00 Keramik 05 Peças</p>
                   <p2></p2>
                   <h1>R$ 70,64</h1>
               </div>    

               <div>  
                   <img src="/assets/img/produtos/imag9.png"></img>
                   <p>Pincéis Atlas 319/5 Trincha para Pintura 2" Amarelo</p>
                   <p2>de: R$ 7,90</p2>
                   <h1>R$ 3,95/cada</h1>
               </div>    


           </div>
           <nav> 
               <a> 1</a>
               <a> 2</a>
               <a> 3</a>
               <a> Prómixo </a>

             </nav>
            <img src="/assets/img/logo.png"></img>



        </div>


    )
}